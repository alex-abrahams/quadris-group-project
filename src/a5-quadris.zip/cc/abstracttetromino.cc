#include "abstracttetromino.h"

AbstractTetromino::AbstractTetromino() {}
AbstractTetromino::~AbstractTetromino() {}


// implementations of functions in concrete class tetrominoblock.

